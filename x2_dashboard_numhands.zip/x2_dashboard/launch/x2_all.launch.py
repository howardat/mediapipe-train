"""Bring up detection, gesture and the dashboard.

This is what setup.sh runs. One launch file rather than four start scripts
because the point of the deployment is a single command, and because ros2
launch already does the process supervision those scripts were each doing
separately.

Three deliberate omissions:

* x2_greeter is off by default. Its own README says it is deliberately not
  started at boot -- a robot that greets people the moment it powers on is not
  what you want while developing -- and it needs MANGISOZ_API_KEY and audio
  focus besides. `greeter:=true` opts in.
* x2_lidar_proximity is off by default. The dashboard no longer displays
  proximity, and on a box where every model runs on the CPU an unwatched node
  is cycles taken from YOLO. `lidar:=true` opts in.
* Nothing here sets FASTRTPS_DEFAULT_PROFILES_FILE or ROS_DOMAIN_ID. Those are
  process environment, not launch arguments, and setup.sh exports them before
  this file is ever read. Setting them here would be too late for DDS anyway.

The nodes are independent processes and start in no particular order. Nothing
waits for anything: x2_gesture and x2_yolo_stream each discover the camera
topic on their own, x2_dashboard shows "no data" until its topics appear, and
a node that dies does not take the others with it.
"""

import os

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

# Same default the start scripts use. setup.sh exports X2_YOLO_WS from its own
# location, so a workspace copied somewhere else still resolves.
WORKSPACE = os.environ.get("X2_YOLO_WS", "/home/agi/x2_yolo_plus_ws")


def generate_launch_description():
    args = [
        DeclareLaunchArgument("image_topic", default_value="",
                              description="camera topic ('' = auto-pick)"),
        DeclareLaunchArgument("yolo", default_value="true"),
        DeclareLaunchArgument("gesture", default_value="true"),
        # Off by default: the dashboard no longer shows proximity, and on a
        # box where every model runs on the CPU an unwatched node is cycles
        # taken from YOLO. `lidar:=true` brings it back -- it still publishes
        # /lidar/proximity for anything else that subscribes.
        DeclareLaunchArgument("lidar", default_value="false"),
        DeclareLaunchArgument("dashboard", default_value="true"),
        DeclareLaunchArgument(
            "greeter", default_value="false",
            description="opt-in: needs MANGISOZ_API_KEY and speaks out loud"),
        DeclareLaunchArgument(
            "gesture_infer_fps", default_value="10.0",
            description="landmarking is on the CPU by default, so this "
                        "competes with YOLO -- raise it with gesture_delegate"),
        DeclareLaunchArgument("gesture_threshold", default_value="0.75"),
        # Hands detected and classified, 1..4. Each hand in frame is another
        # featurize plus another forward pass inside gesture_infer_fps, and
        # landmarking is on the CPU next to YOLO here -- so this is the knob to
        # bring down if inference_ms climbs on a crowded frame.
        DeclareLaunchArgument(
            "gesture_num_hands", default_value="4",
            description="hands to detect and classify, 1..4"),
        # The GPU is x2_yolo_stream's here, deliberately: it gets ~10x from it
        # on much larger models, where MediaPipe's delegate is worth 2-3x on a
        # landmarker whose cost is mostly the frame upload. gesture_delegate:=gpu
        # moves it across when this node has the box to itself. setup.sh sources
        # x2_gesture's gpu_env.sh, so the flag works from here.
        DeclareLaunchArgument(
            "gesture_delegate", default_value="cpu",
            description="cpu | gpu | auto -- MediaPipe delegate"),
    ]

    # Every model path is overridden even though x2_yolo_stream's own defaults
    # now point into this workspace. Belt and braces on purpose: WORKSPACE
    # follows X2_YOLO_WS, so a workspace copied somewhere other than
    # /home/agi/x2_yolo_plus_ws still resolves, and pose_model_path in
    # particular is loaded unconditionally -- getting it wrong is a node that
    # will not start rather than one that degrades.
    yolo = Node(
        package="x2_yolo_stream", executable="yolo_stream",
        name="x2_yolo_stream", output="screen",
        condition=IfCondition(LaunchConfiguration("yolo")),
        parameters=[{
            "image_topic": LaunchConfiguration("image_topic"),
            "model_path": WORKSPACE + "/models/yolox_nano.onnx",
            "pose_model_path": WORKSPACE + "/models/yolov8n-pose.onnx",
            "seg_model_path": WORKSPACE + "/models/wda11s-seg.onnx",
            # Would already land here -- an empty trt_cache_dir resolves next
            # to model_path -- but pinned so the engine cache cannot follow a
            # model_path override out of the workspace.
            "trt_cache_dir": WORKSPACE + "/models/trt_cache",
            "port": 8081,
        }],
    )

    gesture = Node(
        package="x2_gesture", executable="gesture_node",
        name="x2_gesture", output="screen",
        condition=IfCondition(LaunchConfiguration("gesture")),
        parameters=[{
            "image_topic": LaunchConfiguration("image_topic"),
            "model_path": WORKSPACE + "/models/gesture_model.json",
            "landmarker_path": WORKSPACE + "/models/hand_landmarker.task",
            "delegate": LaunchConfiguration("gesture_delegate"),
            "infer_fps": LaunchConfiguration("gesture_infer_fps"),
            "threshold": LaunchConfiguration("gesture_threshold"),
            "num_hands": LaunchConfiguration("gesture_num_hands"),
            "port": 8082,
        }],
    )

    lidar = Node(
        package="x2_lidar_proximity", executable="lidar_proximity",
        name="x2_lidar_proximity", output="screen",
        condition=IfCondition(LaunchConfiguration("lidar")),
    )

    dashboard = Node(
        package="x2_dashboard", executable="dashboard",
        name="x2_dashboard", output="screen",
        condition=IfCondition(LaunchConfiguration("dashboard")),
        parameters=[{"port": 8080}],
    )

    greeter = Node(
        package="x2_greeter", executable="greeter",
        name="x2_greeter", output="screen",
        condition=IfCondition(LaunchConfiguration("greeter")),
    )

    return LaunchDescription(args + [yolo, gesture, lidar, dashboard, greeter])
