#!/bin/bash
# Boot entry point for the gesture node.
#
# Run by the systemd --user unit scripts/x2-gesture.service, and by hand.
#
# Either way the process gets almost no environment -- systemd --user does not
# read ~/.bashrc -- so everything the node needs is set up explicitly here
# rather than inherited from a shell that will not be there. Runs from /tmp
# because the robot's FastDDS profile writes fastdds.log into the working
# directory.
#
# Under the unit:  systemctl --user status x2-gesture
#                  journalctl --user -u x2-gesture -f
# By hand:         tail -f /tmp/x2_gesture.log

# No `set -u`: ROS's own setup.bash reads unbound variables and would abort.

# X2_YOLO_WS, the same variable start_yolo_stream.sh and start_greeter.sh read:
# the workspace setup.sh exports it once from its own location, and all four
# packages follow. The default below is only for running this script bare.
WS="${X2_YOLO_WS:-/home/agi/x2_yolo_plus_ws}"
LOG="${X2_GESTURE_LOG:-/tmp/x2_gesture.log}"
MODEL="${X2_GESTURE_MODEL:-$WS/models/gesture_model.json}"
LANDMARKER="${X2_GESTURE_LANDMARKER:-$WS/models/hand_landmarker.task}"
# Deliberately "cpu" and not "auto". The GPU on this box is x2_yolo_stream's:
# it gets ~10x there on a much larger model, where MediaPipe's delegate is
# worth 2-3x on a landmarker whose cost is mostly the frame upload. Two nodes
# contending for one GPU to accelerate the cheaper of them is the wrong trade.
# X2_GESTURE_DELEGATE=gpu moves it across, and gpu_env.sh below is exactly
# what makes that work.
DELEGATE="${X2_GESTURE_DELEGATE:-cpu}"
# 10 fps is comfortable on the CPU alongside x2_yolo_stream. If you do move
# this node to the GPU, raise it -- a cap chosen for the CPU throws most of
# the speedup away.
INFER_FPS="${X2_GESTURE_INFER_FPS:-10.0}"
THRESHOLD="${X2_GESTURE_THRESHOLD:-0.75}"
# Hands detected and classified, 1..4. Each one in frame costs another
# featurize plus another forward pass inside the INFER_FPS budget, so if
# inference_ms climbs on a crowded frame, this is the knob to bring down.
NUM_HANDS="${X2_GESTURE_NUM_HANDS:-4}"
# Web view. 8081 belongs to x2_yolo_stream.
PORT="${X2_GESTURE_PORT:-8082}"

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [ -z "$X2_GESTURE_FOREGROUND" ]; then
  exec >>"$LOG" 2>&1
fi

# One instance per port: a boot entry and a manual start must not both publish
# contradictory gestures onto the same topic. Keyed by port so a second
# instance watching another camera on another port is still possible.
LOCK="/tmp/x2_gesture.$PORT.lock"
exec 9>"$LOCK"
if ! flock -n 9; then
  [ -n "$X2_GESTURE_QUIET" ] || \
    echo "=== $(date -Is) already running, not starting a second copy ==="
  exit 0
fi

echo "=== start_gesture $(date -Is) ==="

# GPU mediapipe + the GL and CUDA library paths. None of this can be set from
# inside the process, so it has to happen before python starts. Sourced after
# the redirect above, unlike x2_yolo_stream's copy, so that what it reports
# lands in this session's log rather than on whatever terminal ran the script.
# shellcheck source=gpu_env.sh
. "$HERE/gpu_env.sh"

source /opt/ros/humble/setup.bash
if [ -f "$WS/install/setup.bash" ]; then
  source "$WS/install/setup.bash"
else
  echo "workspace not built at $WS/install -- run:"
  echo "  cd $WS && colcon build --packages-select x2_gesture"
  exit 1
fi

if [ ! -f "$MODEL" ]; then
  echo "no gesture model at $MODEL -- copy gesture_model.json from the export"
  exit 1
fi
if [ ! -f "$LANDMARKER" ]; then
  echo "no hand landmarker at $LANDMARKER -- fetch it with:"
  echo "  curl -o $LANDMARKER https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task"
  exit 1
fi

# Without this profile a fresh participant cannot see topics published from the
# other SoCs, which includes every camera.
export FASTRTPS_DEFAULT_PROFILES_FILE=/agibot/data/home/agi/.aima/env/ros_dds_configuration.xml
export ROS_DOMAIN_ID="${ROS_DOMAIN_ID:-0}"
export ROS_LOCALHOST_ONLY=0

cd /tmp || exit 1

echo "--- launching $(date -Is) ---"

# Under systemd: exec, so the unit tracks the real process and Restart=always
# does the supervising. A wrapper that loops internally looks permanently
# healthy to systemd even while the node crashes every ten seconds.
if [ -n "$X2_GESTURE_FOREGROUND" ]; then
  exec ros2 run x2_gesture gesture_node \
    --ros-args \
    -p "model_path:=$MODEL" \
    -p "landmarker_path:=$LANDMARKER" \
    -p "delegate:=$DELEGATE" \
    -p "infer_fps:=$INFER_FPS" \
    -p "threshold:=$THRESHOLD" \
    -p "num_hands:=$NUM_HANDS" \
    -p "port:=$PORT"
fi

# Standalone: at boot the camera stack may still be coming up; the node waits
# for its topic on its own, but if it exits for any reason keep bringing it
# back.
while true; do
  ros2 run x2_gesture gesture_node \
    --ros-args \
    -p "model_path:=$MODEL" \
    -p "landmarker_path:=$LANDMARKER" \
    -p "delegate:=$DELEGATE" \
    -p "infer_fps:=$INFER_FPS" \
    -p "threshold:=$THRESHOLD" \
    -p "num_hands:=$NUM_HANDS" \
    -p "port:=$PORT"
  echo "node exited with $? -- restarting in 10s"
  sleep 10
  echo "--- launching $(date -Is) ---"
done
