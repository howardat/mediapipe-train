# Sourced, not executed. Puts the GPU-capable mediapipe and the GL/CUDA
# libraries where a process started by systemd --user (or by hand) will find
# them.
#
#   . "$(dirname "$0")/gpu_env.sh"
#
# It is its own file, not lines inside start_gesture.sh, because 'ros2 launch'
# and a bare 'ros2 run' need it too, and the equivalent in x2_yolo_stream was
# inline once: the second node to be written was launched a different way and
# quietly got the CPU build for weeks.
#
# Everything here is an export that must be set BEFORE python starts. The
# delegate parameter cannot compensate for a missing libEGL from inside the
# process -- that is why this is a shell file and not more Python.

# The stock PyPI mediapipe has no aarch64 build at all, so on the robot the
# wheel comes from elsewhere and this account has no sudo. Unpack rather than
# install, exactly as the yolo package does with onnxruntime-gpu: PYTHONPATH
# precedes the site directories, so this shadows any CPU mediapipe for this
# process and nothing else. Undo by deleting the directory.
#
#   mkdir -p ~/mediapipe-gpu && cd ~/mediapipe-gpu
#   pip3 download mediapipe --no-deps -d . \
#       --index-url https://pypi.jetson-ai-lab.io/jp6/cu129
#   python3 -m zipfile -e mediapipe-*.whl pkg
#
# Leave X2_GESTURE_MEDIAPIPE unset and nothing is shadowed: whatever
# 'pip show mediapipe' points at is what runs.
MP_GPU="${X2_GESTURE_MEDIAPIPE:-}"
if [ -n "$MP_GPU" ] && [ -d "$MP_GPU" ]; then
  export PYTHONPATH="$MP_GPU${PYTHONPATH:+:$PYTHONPATH}"
  echo "mediapipe from $MP_GPU"
elif [ -n "$MP_GPU" ]; then
  echo "X2_GESTURE_MEDIAPIPE=$MP_GPU does not exist -- using the installed mediapipe"
fi

# Neither systemd --user nor cron reads ~/.bashrc, so a node that finds libEGL
# in an interactive shell can fail to at boot and fall back to the CPU with one
# line of log to say so. The tegra directories are where JetPack puts the real
# EGL/GLES implementation; adding them costs nothing when they are already on
# the loader path.
for _d in /usr/lib/aarch64-linux-gnu/tegra-egl \
          /usr/lib/aarch64-linux-gnu/tegra \
          /usr/local/cuda/lib64; do
  [ -d "$_d" ] && case ":${LD_LIBRARY_PATH:-}:" in
    *":$_d:"*) ;;
    *) export LD_LIBRARY_PATH="$_d${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}" ;;
  esac
done
unset _d

# The delegate opens an EGL display, and on a headless box that means the
# device platform rather than an X server. Naming the vendor library keeps a
# stray Mesa ICD from being picked ahead of NVIDIA's, which fails in a way that
# reads as "no GPU" rather than as a configuration mistake.
if [ -f /usr/share/glvnd/egl_vendor.d/10_nvidia.json ]; then
  export __EGL_VENDOR_LIBRARY_FILENAMES="${__EGL_VENDOR_LIBRARY_FILENAMES:-/usr/share/glvnd/egl_vendor.d/10_nvidia.json}"
fi

# Check by hand, when the node says it is on the CPU and you expected otherwise:
#
#   python3 -c "import ctypes; ctypes.CDLL('libEGL.so.1'); print('EGL ok')"
#   python3 -c "import mediapipe; print(mediapipe.__version__, mediapipe.__file__)"
