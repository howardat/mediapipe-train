"""Launch the gesture node with the robot's defaults.

Landmarking is on the CPU here, deliberately: the Orin's GPU is
x2_yolo_stream's, which gets far more out of it. delegate:=gpu moves it, and
if you do that, note that the GPU delegate needs LD_LIBRARY_PATH set before
the process starts -- no launch file can arrange that from the inside. Either
start through scripts/start_gesture.sh, which sources scripts/gpu_env.sh for
you, or source it yourself first:

    . src/x2_gesture/scripts/gpu_env.sh
    ros2 launch x2_gesture x2_gesture.launch.py delegate:=gpu

Asking for the GPU without it is the quiet failure worth knowing about: the
node comes up, publishes correctly, and runs on the CPU. It logs a warning
when that happens, and the startup log says which delegate it got.
"""

from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    args = [
        DeclareLaunchArgument("image_topic", default_value="",
                              description="camera topic ('' = auto-pick)"),
        DeclareLaunchArgument(
            "model_path",
            default_value="/home/agi/x2_yolo_plus_ws/models/gesture_model.json"),
        DeclareLaunchArgument(
            "landmarker_path",
            default_value="/home/agi/x2_yolo_plus_ws/models/hand_landmarker.task"),
        DeclareLaunchArgument(
            "delegate", default_value="cpu",
            description="cpu | gpu | auto -- the GPU belongs to "
                        "x2_yolo_stream by default; see the README"),
        DeclareLaunchArgument("threshold", default_value="0.75",
                              description="confidence to commit a gesture"),
        DeclareLaunchArgument("smoothing", default_value="5",
                              description="frames averaged before committing"),
        DeclareLaunchArgument(
            "num_hands", default_value="4",
            description="hands to detect and classify, 1..4 -- each gets its "
                        "own smoothing window and an entry in per_hand"),
        DeclareLaunchArgument("infer_fps", default_value="10.0"),
        DeclareLaunchArgument(
            "summary_on_change_only", default_value="true",
            description="false = /gesture/summary every cycle"),
        DeclareLaunchArgument("port", default_value="8082",
                              description="web view; 8081 is x2_yolo_stream"),
        DeclareLaunchArgument("publish_web", default_value="true"),
    ]
    node = Node(
        package="x2_gesture",
        executable="gesture_node",
        name="x2_gesture",
        output="screen",
        parameters=[{
            "image_topic": LaunchConfiguration("image_topic"),
            "model_path": LaunchConfiguration("model_path"),
            "landmarker_path": LaunchConfiguration("landmarker_path"),
            "delegate": LaunchConfiguration("delegate"),
            "threshold": LaunchConfiguration("threshold"),
            "smoothing": LaunchConfiguration("smoothing"),
            "num_hands": LaunchConfiguration("num_hands"),
            "infer_fps": LaunchConfiguration("infer_fps"),
            "summary_on_change_only":
                LaunchConfiguration("summary_on_change_only"),
            "port": LaunchConfiguration("port"),
            "publish_web": LaunchConfiguration("publish_web"),
        }],
    )
    return LaunchDescription(args + [node])
