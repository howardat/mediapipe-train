"""Feature extraction and classification for a Gesture Atlas model.

GENERATED — do not edit. Emitted from src/lib/features.ts, and byte-identical
to the corresponding section of infer.py.

Imports nothing but json and numpy on purpose, so it can be exercised on a
machine with no OpenCV, MediaPipe or ROS.
"""

import json

import numpy as np

# ---------------------------------------------------------------- feature spec
NUM_LANDMARKS = 21
FINGER_CHAINS = [[0,1,2,3,4],[0,5,6,7,8],[0,9,10,11,12],[0,13,14,15,16],[0,17,18,19,20]]
TIP_INDICES = [4,8,12,16,20]
SCALE_REF = [0,9]
MIRROR_LEFT_HAND = True
FEATURE_DIM = 88
SPEC_VERSION = 1


def featurize(world_landmarks, handedness):
    """21x3 world landmarks -> feature vector. Mirrors src/lib/features.ts."""
    pts = np.asarray(world_landmarks, dtype=np.float64).reshape(NUM_LANDMARKS, 3)

    if MIRROR_LEFT_HAND and handedness == "Left":
        pts = pts * np.array([-1.0, 1.0, 1.0])

    pts = pts - pts[SCALE_REF[0]]
    ref = np.linalg.norm(pts[SCALE_REF[1]])
    pts = pts / (ref if ref > 1e-6 else 1.0)

    feats = [pts.reshape(-1)]

    angles = []
    for chain in FINGER_CHAINS:
        bones = [pts[chain[i + 1]] - pts[chain[i]] for i in range(len(chain) - 1)]
        for i in range(len(bones) - 1):
            la = np.linalg.norm(bones[i])
            lb = np.linalg.norm(bones[i + 1])
            if la > 1e-6 and lb > 1e-6:
                angles.append(float(np.dot(bones[i], bones[i + 1]) / (la * lb)))
            else:
                angles.append(0.0)
    feats.append(np.asarray(angles))

    dists = []
    for i in range(len(TIP_INDICES)):
        for j in range(i + 1, len(TIP_INDICES)):
            dists.append(float(np.linalg.norm(pts[TIP_INDICES[i]] - pts[TIP_INDICES[j]])))
    feats.append(np.asarray(dists))

    return np.concatenate(feats).astype(np.float32)


# ------------------------------------------------------------------ classifier
class GestureClassifier:
    def __init__(self, path):
        with open(path) as fh:
            bundle = json.load(fh)

        spec = bundle["featureSpec"]
        if spec["version"] != SPEC_VERSION:
            raise SystemExit(
                "Feature spec mismatch: model is v%s, this script is v%s. Re-export."
                % (spec["version"], SPEC_VERSION)
            )

        self.classes = bundle["classes"]
        self.mean = np.asarray(bundle["standardization"]["mean"], dtype=np.float32)
        self.std = np.asarray(bundle["standardization"]["std"], dtype=np.float32)
        self.layers = [
            (
                np.asarray(l["w"], dtype=np.float32),
                np.asarray(l["b"], dtype=np.float32),
                l["activation"],
            )
            for l in bundle["layers"]
        ]
        self.golden = bundle["golden"]
        self.val_accuracy = bundle.get("valAccuracy", float("nan"))

    def predict(self, feats):
        x = (feats - self.mean) / self.std
        for w, b, activation in self.layers:
            x = x @ w + b
            if activation == "relu":
                x = np.maximum(x, 0.0)
            elif activation == "softmax":
                x = np.exp(x - x.max())
                x = x / x.sum()
        return x

    def verify(self):
        """Fails loudly at startup if this featurizer disagrees with the browser.

        Without this, a normalization mismatch produces confident wrong answers
        instead of an error, which is far more expensive to debug in the field.
        """
        g = self.golden
        feats = featurize(g["worldLandmarks"], g["handedness"])
        expected_feats = np.asarray(g["features"], dtype=np.float32)
        feat_err = float(np.abs(feats - expected_feats).max())

        probs = self.predict(feats)
        prob_err = float(np.abs(probs - np.asarray(g["probs"], dtype=np.float32)).max())
        predicted = self.classes[int(np.argmax(probs))]

        ok = feat_err < 1e-3 and prob_err < 1e-3 and predicted == g["expectedClass"]
        status = "PASS" if ok else "FAIL"
        print(
            "[golden] %s  feature_err=%.2e  prob_err=%.2e  predicted=%s expected=%s"
            % (status, feat_err, prob_err, predicted, g["expectedClass"])
        )
        if not ok:
            raise SystemExit("Golden-sample check failed — features do not match the browser.")
