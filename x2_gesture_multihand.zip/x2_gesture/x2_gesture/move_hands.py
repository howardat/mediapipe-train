#!/usr/bin/env python3
import rclpy
import json
import time
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSReliabilityPolicy, QoSDurabilityPolicy, QoSHistoryPolicy

# ROS 2 Messages & Services
from std_msgs.msg import String
from aimdk_msgs.msg import RequestHeader, McPresetMotion, McControlArea
from aimdk_msgs.srv import SetMcPresetMotion

# Custom LLM Message (kept from your original code)
from qbot_msgs.msg import LLMResp

class MoveHands(Node):

    def __init__(self):
        super().__init__('motion_expression_node')

        llm_qos = QoSProfile(
            reliability=QoSReliabilityPolicy.RELIABLE,
            durability=QoSDurabilityPolicy.VOLATILE,
            history=QoSHistoryPolicy.KEEP_LAST,
            depth=10
        )

        # 1. Define your gesture-to-motion dictionary here
        # Format: "gesture_name": (motion_val, area_val)
        self.gesture_map = {
            "okay": (3017, 11),
            "korean_love": (1007, 3),
            "phone": (1004, 1)
        }

        # 2. Setup cooldown variables for the 10-second throttle
        self.last_gesture_time = 0.0
        self.cooldown_period = 10.0  # seconds

        # 3. Add subscription to the new JSON string topic
        # Update '/gesture_detections' to match the actual topic name your other script publishes to
        self.gesture_sub = self.create_subscription(
            String, '/gesture/detections', self.gesture_callback, 10)

        # Service client for preset motions
        self.motion_client = self.create_client(SetMcPresetMotion, '/aimdk_5Fmsgs/srv/SetMcPresetMotion')

        while not self.motion_client.wait_for_service(timeout_sec=2.0):
            self.get_logger().info("Waiting for SetMcPresetMotion service...")

        self.get_logger().info("Motion Expression Node active. Listening for LLM and Gestures...")

    def execute_preset_motion(self, motion_val: int, area_val: int):
        self.get_logger().info(f"Executing Motion: {motion_val}, Area: {area_val}")
        req = SetMcPresetMotion.Request()
        req.header = RequestHeader()
        req.header.stamp = self.get_clock().now().to_msg()
        motion = McPresetMotion()
        motion.value = int(motion_val)
        area = McControlArea()
        area.value = int(area_val)
        req.motion = motion
        req.area = area
        req.interrupt = True
        req.play_timestamp = 0
        self.motion_client.call_async(req)

    def gesture_callback(self, msg: String):
        current_time = time.time()

        # Enforce the 10-second cooldown
        if current_time - self.last_gesture_time < self.cooldown_period:
            return

        try:
            # Parse the incoming JSON string
            data = json.loads(msg.data)
            
            # Extract the gesture (the "label" from your publisher)
            gesture = data.get("gesture")
            
            # Optional: You can also extract and check confidence
            # confidence = data.get("confidence", 0.0)
            # if confidence < 0.5: return

            if gesture and gesture in self.gesture_map:
                motion_val, area_val = self.gesture_map[gesture]
                
                self.get_logger().info(f"Gesture '{gesture}' detected! Triggering mapped motion.")
                self.execute_preset_motion(motion_val, area_val)
                
                # Update the timestamp so it waits another 10 seconds
                self.last_gesture_time = current_time

        except json.JSONDecodeError:
            self.get_logger().error("Received string is not valid JSON.")
        except Exception as e:
            self.get_logger().error(f"Error processing gesture data: {e}")


def main(args=None):
    rclpy.init(args=args)
    node = MoveHands()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()

if __name__ == '__main__':
    main()
