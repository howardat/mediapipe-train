"""One place that decides whether the hand landmarker runs on the GPU.

Runnable on its own, which is also how it tests a delegate:

    python3 runtime.py --probe /path/to/hand_landmarker.task gpu

Shaped after x2_yolo_stream/runtime.py, which does this for onnxruntime, and
written for the same reason: before it, every model in this workspace opened
with a hard-coded CPU backend, so on a Jetson Orin NX the GPU sat idle while
six ARM cores did convolutions.

MediaPipe has no execution providers. It has one delegate field on BaseOptions
and the TFLite GPU delegate behind it -- OpenGL ES compute shaders, not CUDA
and not TensorRT, so none of x2_yolo_stream's TensorRT machinery applies. Two
things about it do not survive being copied from that file, and both were
found the expensive way:

* **MediaPipe does not raise, it aborts.** A delegate that cannot run fails
  inside C++ as a CHECK failure, which calls abort(). There is no Python
  exception, so there is nothing for try/except to catch: the node does not
  fall back, it dies. That is why every delegate above the last one is tried
  in a SEPARATE PROCESS first (see probe) and only built in this one after a
  child has survived it. A robot whose GPU stack is broken has to come up
  slowly, not blind.
* **The GPU path only accepts 4-channel images.** Handing SRGB to a GPU
  landmarker aborts with "unsupported ImageFrame format", so the conversion
  differs per delegate: SRGBA for the GPU, SRGB for the CPU. Landmarker owns
  that conversion. A caller that builds its own mp.Image has to remember which
  delegate it got, and will eventually get it wrong.

Expect roughly 2-3x from the GPU, not the 10x it gives onnxruntime. The
landmarker is a small model and every frame is uploaded from CPU memory. Once
inference is cheap the JPEG decode and encode around it are the budget.
"""

import os
import subprocess
import sys
import time

# Preference order for "auto". Only two rungs, unlike onnxruntime's three.
DELEGATE_ORDER = ("gpu", "cpu")

# A human types "gpu" on the command line; something scripted passes back
# whatever this module reported, which is also "gpu"/"cpu". Both have to land
# in the same place -- the equivalent lookup in x2_yolo_stream was
# case-sensitive once and quietly benchmarked the CPU for an evening.
ALIASES = {
    "gpu": "gpu",
    "cuda": "gpu",
    "opengl": "gpu",
    "gl": "gpu",
    "cpu": "cpu",
    "xnnpack": "cpu",
}

LABELS = {
    "gpu": "GPU (TFLite delegate, OpenGL ES)",
    "cpu": "CPU (XNNPACK)",
}

# How long a probe child gets before it is called a failure. Generous: it pays
# for a cold mediapipe import and a 7 MB model load on a busy Orin, and the
# only thing a too-short timeout buys is a robot that runs on the CPU forever.
PROBE_TIMEOUT = 120.0


def resolve_chain(requested):
    """'auto' | 'gpu' | 'cpu' | 'gpu,cpu' -> list of delegates to try.

    Unknown names are dropped rather than raised on, and "cpu" is always
    appended, because a node that refuses to start is worse than a node that
    runs slowly: this one is a robot's eyes.
    """
    requested = (requested or "auto").strip().lower()

    if requested in ("auto", "", "best"):
        wanted = list(DELEGATE_ORDER)
    else:
        wanted = []
        for part in requested.replace(" ", "").split(","):
            name = ALIASES.get(part)
            if name is not None and name not in wanted:
                wanted.append(name)

    if "cpu" not in wanted:
        wanted.append("cpu")
    return wanted


def _one_line(text):
    """MediaPipe errors arrive as paragraphs of C++ log. Keep it to a line."""
    return " ".join(str(text).split())[:200]


def _interesting(stderr):
    """The line of a probe's output worth putting in the log.

    MediaPipe is loud on stderr even when everything works, so the last line
    is usually a stack frame and the first is usually a banner. A CHECK
    failure is the line that starts with F<digits>, and it is the one that
    says what actually went wrong.
    """
    lines = [line.strip() for line in stderr.splitlines() if line.strip()]
    for line in lines:
        if line[:1] == "F" and "Check failed" in line:
            return _one_line(line)
    for line in reversed(lines):
        if not line.startswith(("I0", "W0", "INFO:", "@", "***")):
            return _one_line(line)
    return _one_line(lines[-1]) if lines else "no output"


def _base_options(model_path, delegate):
    from mediapipe.tasks import python as mp_python

    kinds = mp_python.BaseOptions.Delegate
    return mp_python.BaseOptions(
        model_asset_path=model_path,
        delegate=kinds.GPU if delegate == "gpu" else kinds.CPU,
    )


def open_raw(model_path, delegate, num_hands=1, min_detection_confidence=0.5,
             min_tracking_confidence=0.5):
    """A bare HandLandmarker on one delegate. No probe, no fallback.

    Used by make_landmarker once a delegate is known good, and by the probe
    child, which is what makes it known good. Nothing else should call it:
    on its own it is the abort-instead-of-falling-back behaviour this module
    exists to prevent.
    """
    from mediapipe.tasks.python import vision

    return vision.HandLandmarker.create_from_options(
        vision.HandLandmarkerOptions(
            base_options=_base_options(model_path, delegate),
            running_mode=vision.RunningMode.VIDEO,
            num_hands=num_hands,
            min_hand_detection_confidence=min_detection_confidence,
            min_tracking_confidence=min_tracking_confidence,
        )
    )


def to_image(frame_bgr, delegate):
    """An OpenCV BGR frame -> the mp.Image this delegate can actually take.

    The GPU path rejects 3-channel data outright -- not with an exception,
    with an abort -- so the channel count is not a detail to leave to the
    caller.
    """
    import cv2
    import mediapipe as mp

    if delegate == "gpu":
        rgba = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGBA)
        return mp.Image(image_format=mp.ImageFormat.SRGBA, data=rgba)
    rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
    return mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)


def blank_image(delegate, size=256):
    """A frame of nothing, in this delegate's format. numpy only, no cv2."""
    import mediapipe as mp
    import numpy as np

    if delegate == "gpu":
        data = np.zeros((size, size, 4), dtype=np.uint8)
        data[:, :, 3] = 255
        return mp.Image(image_format=mp.ImageFormat.SRGBA, data=data)
    return mp.Image(image_format=mp.ImageFormat.SRGB,
                    data=np.zeros((size, size, 3), dtype=np.uint8))


def warmup(landmarker, delegate, runs=3, start_timestamp_ms=0):
    """Push blank frames through the graph. Returns (ms, last timestamp).

    The milliseconds are a floor, not the per-frame cost. A blank frame has no
    hand in it, so the palm detector runs and the landmark model does not. The
    honest number is the node's own inference_ms, measured on real frames and
    published every cycle.
    """
    image = blank_image(delegate)

    timestamp = int(start_timestamp_ms)
    elapsed = 0.0
    for _ in range(max(1, runs)):
        timestamp += 1
        started = time.monotonic()
        landmarker.detect_for_video(image, timestamp)
        elapsed = (time.monotonic() - started) * 1000.0
    return elapsed, timestamp


class Landmarker:
    """A HandLandmarker that knows what it runs on and owns its clock.

    The clock is not a convenience. VIDEO mode rejects a timestamp that is not
    strictly greater than the last one it saw, and "the last one it saw"
    includes the frames warmup() pushed through. Keeping the counter here
    means one place can get it wrong instead of one per caller, and it also
    survives a monotonic clock that returns the same millisecond twice at a
    high infer_fps.
    """

    def __init__(self, landmarker, delegate, warmup_ms, timestamp_ms=0):
        self._landmarker = landmarker
        self.delegate = delegate
        self.label = LABELS.get(delegate, delegate)
        self.warmup_ms = warmup_ms
        self._last_ts = int(timestamp_ms)
        self._base = int(timestamp_ms) + 1
        self._started = time.monotonic()

    def detect(self, frame_bgr):
        """One OpenCV BGR frame -> a HandLandmarkerResult."""
        image = to_image(frame_bgr, self.delegate)
        stamp = self._base + int((time.monotonic() - self._started) * 1000.0)
        if stamp <= self._last_ts:
            stamp = self._last_ts + 1
        self._last_ts = stamp
        return self._landmarker.detect_for_video(image, stamp)

    def close(self):
        """Release the graph, and with it the GL context on the GPU path."""
        try:
            self._landmarker.close()
        except Exception:                                   # noqa: BLE001
            pass


def probe(model_path, delegate, timeout=PROBE_TIMEOUT):
    """Does this delegate work? Answered in a child process. -> (ok, detail).

    The child is this file, run as a script. It builds the landmarker and
    pushes frames through it, which is the whole of what can abort, and the
    abort lands on the child instead of on the node.

    The environment is inherited deliberately: PYTHONPATH and LD_LIBRARY_PATH
    from scripts/gpu_env.sh are most of what decides the answer, so the child
    has to be looking at the same libraries the parent will.
    """
    command = [sys.executable, os.path.abspath(__file__), "--probe",
               model_path, delegate]
    try:
        done = subprocess.run(command, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, timeout=timeout)
    except subprocess.TimeoutExpired:
        return False, "probe timed out after %.0fs" % timeout
    except OSError as exc:
        # No interpreter, no file -- do not let a broken probe be read as a
        # broken delegate. Say so and let the caller decide.
        return False, "could not run the probe: %s" % _one_line(exc)

    if done.returncode == 0:
        return True, ""

    stderr = done.stderr.decode("utf-8", "replace")
    if done.returncode < 0:
        # Negative means a signal. This is the case the whole probe exists
        # for: SIGABRT from a CHECK failure inside MediaPipe.
        return False, ("crashed with signal %d: %s"
                       % (-done.returncode, _interesting(stderr)))
    return False, _interesting(stderr)


def make_landmarker(model_path, delegate="auto", num_hands=1,
                    min_detection_confidence=0.5, min_tracking_confidence=0.5,
                    warmup_runs=3, probe_first=True, logger=None):
    """Open a hand landmarker on the fastest delegate that actually works.

    Returns a Landmarker whose .delegate is what was built, not what was asked
    for -- "GPU requested, running on CPU" is exactly the failure this module
    exists to make visible.

    probe_first=False skips the subprocess check and saves the few seconds it
    costs. Only do that where a crash is cheap: on the robot the node is the
    eyes, and a delegate that aborts takes the whole node with it.
    """
    def say(message):
        if logger is not None:
            logger(message)

    name = os.path.basename(model_path)
    chain = resolve_chain(delegate)
    last_error = "no delegate was tried"

    for i, kind in enumerate(chain):
        # The last rung is not probed. There is nothing to fall back TO, so a
        # probe could only turn a slow start into a slow start plus a wrong
        # error message.
        if probe_first and i < len(chain) - 1:
            started = time.monotonic()
            ok, detail = probe(model_path, kind)
            if not ok:
                last_error = detail
                say("%s: %s delegate unusable (%s); trying next"
                    % (name, kind, detail))
                continue
            say("%s: %s delegate verified in a child process (%.1fs)"
                % (name, kind, time.monotonic() - started))

        try:
            landmarker = open_raw(model_path, kind, num_hands,
                                  min_detection_confidence,
                                  min_tracking_confidence)
            elapsed_ms, timestamp = warmup(landmarker, kind, warmup_runs)
        except Exception as exc:                            # noqa: BLE001
            # Reachable for the ordinary failures -- a missing file, a corrupt
            # model. The violent ones were caught by the probe above.
            last_error = _one_line(exc)
            say("%s: %s delegate failed to open (%s); trying next"
                % (name, kind, last_error))
            continue

        say("%s: running on the %s" % (name, LABELS.get(kind, kind)))
        return Landmarker(landmarker, kind, elapsed_ms, timestamp)

    raise RuntimeError("no delegate could load %s: %s"
                       % (model_path, last_error))


def _loadable(soname):
    """Can the dynamic loader find this library right now?

    ctypes.util.find_library is the obvious call and the wrong one: it shells
    out to ldconfig, which does not know about LD_LIBRARY_PATH. On this robot
    the Tegra GL libraries are reached through exactly that variable, set by
    scripts/gpu_env.sh, so the obvious call reports them missing on a machine
    where they work.
    """
    import ctypes

    try:
        ctypes.CDLL(soname)
        return True
    except OSError:
        return False


def describe_environment(check_gl=True):
    """One line for the log: what mediapipe is this, and what can it see.

    check_gl=False reports the version and stops there. Worth passing when the
    CPU was chosen on purpose: the GL check has to dlopen libEGL to be honest
    about it, and neither loading a graphics library nor a paragraph about a
    delegate nobody asked for belongs in the boot log of a node that is doing
    exactly what it was told.

    A hint, deliberately, and never a verdict. probe() is the authority on
    whether a delegate works, and the two disagree on a Mac, where there is no
    OpenGL ES anywhere and the GPU delegate runs perfectly well on Metal. A
    line that announced "will fall back to the CPU" there would be a confident
    lie in the log, sitting directly above the line saying it got the GPU.
    """
    try:
        import mediapipe as mp
    except Exception as exc:                                # noqa: BLE001
        return "mediapipe not importable: %s" % _one_line(exc)

    version = getattr(mp, "__version__", "unknown")
    if not check_gl:
        return "mediapipe %s" % version

    missing = [name for name, soname in
               (("libEGL", "libEGL.so.1"), ("libGLESv2", "libGLESv2.so.2"))
               if not _loadable(soname)]
    if missing:
        return ("mediapipe %s, %s not loadable -- on a Jetson that is the "
                "usual reason the GPU delegate is refused, and what "
                "scripts/gpu_env.sh is for. Harmless on a Mac, which reaches "
                "its GPU through Metal instead."
                % (version, " and ".join(missing)))
    return "mediapipe %s, OpenGL ES present" % version


def _probe_main(argv):
    """The child half of probe(). Exits 0 only if the delegate really ran.

    Deliberately does everything the node does to a frame, in the same order.
    A probe that skips a step is a probe that passes a delegate the node then
    aborts on.
    """
    if len(argv) < 2:
        sys.stderr.write("usage: runtime.py --probe MODEL gpu|cpu\n")
        return 2

    model_path, delegate = argv[0], ALIASES.get(argv[1].lower(), argv[1])
    landmarker = open_raw(model_path, delegate)
    try:
        elapsed_ms, _ = warmup(landmarker, delegate, runs=2)
    finally:
        try:
            landmarker.close()
        except Exception:                                   # noqa: BLE001
            pass
    sys.stdout.write("%s ok, blank frame %.1f ms\n" % (delegate, elapsed_ms))
    return 0


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--probe":
        raise SystemExit(_probe_main(sys.argv[2:]))
    print(describe_environment())
    print("delegates in preference order: %s"
          % ", ".join(resolve_chain("auto")))
    print("usage: runtime.py --probe MODEL gpu|cpu")
