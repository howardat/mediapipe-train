"""MJPEG + JSON HTTP front end for the gesture node.

Standard-library ThreadingHTTPServer on purpose, the same choice
x2_yolo_stream makes: it avoids putting a second event loop (gevent/flask)
next to the rclpy executor.

The page shows the annotated camera, the committed gesture, and a bar per
class — the bars are what tell you whether a gesture is failing to trigger
because the model is unsure or because the threshold is too high.
"""

import json
import select
import socket
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

PAGE = """<!doctype html>
<title>X2 gesture</title>
<style>
  :root { color-scheme: dark; }
  body { margin: 0; background: #0e1116; color: #e6edf3;
         font: 14px/1.5 system-ui, sans-serif; }
  header { padding: 10px 16px; border-bottom: 1px solid #30363d;
           display: flex; gap: 16px; align-items: baseline; flex-wrap: wrap; }
  h1 { font-size: 15px; margin: 0; font-weight: 600; }
  .meta { color: #8b949e; font-size: 12px; }
  main { display: flex; gap: 16px; padding: 16px; flex-wrap: wrap; }
  img { max-width: 100%; border-radius: 8px; border: 1px solid #30363d;
        background: #000; }
  .panel { min-width: 280px; }
  .gesture { font-size: 34px; font-weight: 600; letter-spacing: -0.5px;
             margin: 0 0 2px; }
  .gesture.none { color: #6e7681; font-weight: 400; }
  .sub { color: #8b949e; font-size: 12px; margin-bottom: 18px; }
  .row { display: flex; align-items: center; gap: 8px; margin-bottom: 6px; }
  .name { width: 110px; font-size: 13px; }
  .bar { display: block; flex: 1; height: 8px; background: #21262d;
         border-radius: 4px; overflow: hidden; }
  /* display:block matters: these are spans, and an inline element ignores
     width, which silently leaves every bar empty. */
  .fill { display: block; height: 100%; background: #3fb950; width: 0;
          transition: width .15s; }
  .fill.under { background: #484f58; }
  .val { width: 46px; text-align: right; font-size: 12px;
         font-variant-numeric: tabular-nums; color: #8b949e; }
  .mark { color: #6e7681; font-size: 11px; margin-top: 10px; }
</style>
<header>
  <h1>X2 gesture</h1>
  <span class="meta" id="meta">connecting...</span>
</header>
<main>
  <img src="/stream" alt="annotated camera stream">
  <div class="panel">
    <p class="gesture none" id="gesture">waiting</p>
    <div class="sub" id="sub">&nbsp;</div>
    <div id="scores"></div>
    <div class="mark" id="mark"></div>
  </div>
</main>
<script>
async function poll() {
  try {
    const r = await fetch('/state', {cache: 'no-store'});
    const d = await r.json();
    document.getElementById('meta').textContent =
      `${d.topic} | ${d.width}x${d.height} | ` +
      // The delegate belongs next to the milliseconds, not in a corner: the
      // same 45 ms is healthy on the CPU and a sign of a broken GPU path.
      `infer ${d.inference_ms} ms on ${(d.delegate || '?').toUpperCase()} | ` +
      `${d.stream_fps} fps in, ${d.infer_fps} fps analysed | spec v${d.spec_version}`;

    const g = document.getElementById('gesture');
    if (d.gesture) {
      g.textContent = d.gesture;
      g.className = 'gesture';
      document.getElementById('sub').textContent =
        `${d.handedness || ''} hand · ${d.confidence.toFixed(2)} · held ${d.held_seconds}s`;
    } else {
      g.textContent = d.hands ? 'unrecognised' : 'no hand';
      g.className = 'gesture none';
      document.getElementById('sub').textContent =
        d.hands ? 'hand visible, nothing over threshold' : '\u00a0';
    }

    const scores = d.scores || {};
    document.getElementById('scores').innerHTML =
      (d.classes || []).map(c => {
        const v = scores[c] || 0;
        const under = v < d.threshold ? ' under' : '';
        return `<div class="row"><span class="name">${c}</span>` +
               `<span class="bar"><span class="fill${under}" style="width:${(v * 100).toFixed(1)}%"></span></span>` +
               `<span class="val">${v.toFixed(2)}</span></div>`;
      }).join('');

    document.getElementById('mark').textContent =
      `threshold ${d.threshold} · smoothing ${d.smoothing} frames · ` +
      `${d.changes} changes · ${d.viewers} viewer(s)`;
  } catch (e) {
    document.getElementById('meta').textContent = 'disconnected';
  }
}
poll(); setInterval(poll, 400);
</script>
"""


def make_handler(state):
    """Build a request handler bound to a SharedState instance."""

    class Handler(BaseHTTPRequestHandler):
        protocol_version = "HTTP/1.1"
        server_version = "x2_gesture"

        def log_message(self, fmt, *args):
            pass                      # the ROS log is the log

        def _send(self, code, body, ctype="text/plain; charset=utf-8"):
            if isinstance(body, str):
                body = body.encode()
            self.send_response(code)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            try:
                self.wfile.write(body)
            except (BrokenPipeError, ConnectionResetError):
                pass

        def _client_gone(self):
            """True once the browser has closed the connection."""
            try:
                rlist, _, _ = select.select([self.connection], [], [], 0)
                if not rlist:
                    return False
                return self.connection.recv(1, socket.MSG_PEEK) == b""
            except OSError:
                return True

        def do_GET(self):
            path = self.path.split("?", 1)[0]
            if path == "/":
                self._send(200, PAGE, "text/html; charset=utf-8")
            elif path == "/state":
                self._send(200, json.dumps(state.snapshot()),
                           "application/json")
            elif path == "/healthz":
                ok = state.frames_in > 0
                self._send(200 if ok else 503,
                           json.dumps({"ok": ok, "frames": state.frames_in}),
                           "application/json")
            elif path == "/snapshot":
                jpeg = state.latest_jpeg()
                if jpeg is None:
                    self._send(503, "no frame yet")
                else:
                    self._send(200, jpeg, "image/jpeg")
            elif path == "/stream":
                self.route_stream()
            else:
                self._send(404, "not found")

        def route_stream(self):
            self.send_response(200)
            self.send_header("Age", "0")
            self.send_header("Cache-Control",
                             "no-store, no-cache, must-revalidate")
            self.send_header("Pragma", "no-cache")
            self.send_header("Connection", "close")
            self.send_header("Content-Type",
                             "multipart/x-mixed-replace; boundary=frame")
            self.end_headers()

            state.add_viewer(+1)
            last_seq = -1
            try:
                while True:
                    if self._client_gone():
                        break
                    jpeg, last_seq = state.wait_for_frame(last_seq, timeout=5.0)
                    if jpeg is None:
                        continue          # nothing published yet; keep waiting
                    self.wfile.write(b"--frame\r\n")
                    self.wfile.write(b"Content-Type: image/jpeg\r\n")
                    self.wfile.write(b"Content-Length: " +
                                     str(len(jpeg)).encode() + b"\r\n\r\n")
                    self.wfile.write(jpeg)
                    self.wfile.write(b"\r\n")
                    self.wfile.flush()
            except (BrokenPipeError, ConnectionResetError, OSError):
                pass
            finally:
                state.add_viewer(-1)

    return Handler


def serve(state, host, port):
    """Start the HTTP server. Returns the server; caller runs/stops it."""
    httpd = ThreadingHTTPServer((host, port), make_handler(state))
    httpd.daemon_threads = True
    return httpd


def local_ips():
    """Best-effort list of addresses the browser could use."""
    ips = []
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("8.8.8.8", 80))
        ips.append(sock.getsockname()[0])
        sock.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None,
                                       socket.AF_INET):
            ip = info[4][0]
            if ip not in ips and not ip.startswith("127."):
                ips.append(ip)
    except OSError:
        pass
    return ips or ["<robot-ip>"]
