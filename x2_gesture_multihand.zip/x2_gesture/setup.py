"""ament_python package definition.

Neither the gesture model nor the hand landmarker is shipped inside the
package: they live in the workspace's models/ directory and are passed in as
the model_path and landmarker_path parameters. Keeping them out of the install
space means colcon builds stay fast and the repository stays free of binaries.
"""

from setuptools import find_packages, setup

PACKAGE_NAME = "x2_gesture"

setup(
    name=PACKAGE_NAME,
    version="1.0.0",
    packages=find_packages(exclude=["test", "test.*"]),
    data_files=[
        ("share/ament_index/resource_index/packages",
         ["resource/" + PACKAGE_NAME]),
        ("share/" + PACKAGE_NAME, ["package.xml"]),
        ("share/" + PACKAGE_NAME + "/launch",
         ["launch/x2_gesture.launch.py"]),
        # Run from src/ on the robot rather than the install space, but ship
        # them too so a fresh checkout has them somewhere findable.
        ("share/" + PACKAGE_NAME + "/scripts",
         ["scripts/start_gesture.sh",
          "scripts/gpu_env.sh",
          "scripts/x2-gesture.service"]),
    ],
    install_requires=["setuptools"],
    zip_safe=True,
    maintainer="Kazbot",
    maintainer_email="dev@kazbot.kz",
    description="Hand-gesture classification on an X2 camera topic, as ROS "
                "topics.",
    license="Proprietary",
    entry_points={
        "console_scripts": [
            "gesture_node = x2_gesture.node:main",
        ],
    },
)
