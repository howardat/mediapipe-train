"""ROS 2 node: camera -> hand landmarks -> gesture label -> topics.

Consumes a compressed camera topic and publishes what the hand is doing. The
classifier is a two-layer MLP exported from Gesture Atlas; the expensive part
is MediaPipe's hand landmarker.

Design notes that matter on this robot:

* Only /compressed camera topics are subscribed. A RAW stream is 75-90 MB/s
  and must not be crossed between compute units; compressed is a few hundred
  kB/s. Set camera_device >= 0 to read a local V4L2 camera instead, which is
  for a dev machine, not for the robot.
* Landmarking runs in its own thread on a latest-frame-wins slot. The DDS
  callback only stores bytes, so a slow frame never stalls the executor and
  never builds a backlog -- old frames are dropped, not queued.
* The golden-sample check runs before any publisher is created. If the
  featurizer here disagrees with the browser that trained the model, the node
  exits instead of publishing confident nonsense onto the graph.
* Landmarking is on the CPU (XNNPACK) by default, and that is a choice rather
  than a limitation. The Orin has one GPU, x2_yolo_stream gets about 10x out
  of it, and MediaPipe's GPU delegate is worth 2-3x here -- so the two nodes
  divide the machine instead of fighting over it. delegate:=gpu moves this one
  across when that trade changes; runtime.py owns the mechanics and proves a
  delegate works in a child process before trusting it, because MediaPipe
  aborts rather than raising when it cannot. Whichever it ends up on is
  logged, shown on the web view, and published as "delegate" on every
  /gesture/detections message. Body-pose keypoints cannot substitute for this:
  they have no fingers.
* The subscription starts best-effort and falls back to reliable if no frame
  arrives, because large fragmented samples from another SoC do not always
  come through on the first QoS choice.
* The web view is served from this process on port 8082 (8081 is
  x2_yolo_stream's). It is the fastest way to see why a gesture is not
  triggering: the per-class bars separate "the model is unsure" from "the
  threshold is too high", which the topics alone make you squint at.
"""

import json
import threading
import time
from collections import deque

import cv2
import numpy as np
import rclpy
from rclpy.node import Node
from rclpy.qos import (DurabilityPolicy, HistoryPolicy, QoSProfile,
                       ReliabilityPolicy)
from sensor_msgs.msg import CompressedImage
from std_msgs.msg import String

from .gesture import SPEC_VERSION, GestureClassifier, featurize
from .runtime import describe_environment, make_landmarker
from .web import local_ips, serve

# Hand skeleton, for the overlay only. Cosmetic: nothing downstream reads it.
HAND_EDGES = [[0,1],[1,2],[2,3],[3,4],[0,5],[5,6],[6,7],[7,8],[5,9],[9,10],[10,11],[11,12],[9,13],[13,14],[14,15],[15,16],[13,17],[17,18],[18,19],[19,20],[0,17]]

# First existing topic wins when image_topic is left empty. Same list as
# x2_yolo_stream, so both nodes land on the same camera by default.
TOPIC_PREFERENCE = [
    "/aima/hal/sensor/rgb_head_front_center/rgb_image/compressed",
    "/aima/hal/sensor/rgbd_head_front/rgb_image/compressed",
    "/aima/hal/sensor/stereo_head_front_left/rgb_image/compressed",
    "/aima/hal/sensor/rgb_head_rear/rgb_image/compressed",
    "/camera/color/image_raw/compressed",
]


def draw_overlay(frame, tracks, threshold):
    """A skeleton per hand plus a label chip.

    tracks is one dict per hand, as _infer_loop assembles them: pixel
    "points", the committed "label" (or None), its "confidence" and
    "handedness". An empty list means the frame had no hand.
    """
    for track in tracks:
        points = track["points"]
        for a, b in HAND_EDGES:
            cv2.line(frame, points[a], points[b], (0, 255, 200), 2,
                     cv2.LINE_AA)
        for i, pt in enumerate(points):
            # The wrist anchors the whole normalization, so it reads heavier.
            cv2.circle(frame, pt, 5 if i == 0 else 3, (255, 255, 255), -1,
                       cv2.LINE_AA)
        if len(tracks) > 1:
            # Only worth the ink with two hands up: which label belongs to
            # which hand is unreadable from one chip, and drawing it twice
            # when there is nothing to disambiguate just clutters the frame.
            tag = ("%s  %.2f" % (track["label"], track["confidence"])
                   if track["label"] else "?  %.2f" % track["confidence"])
            cv2.putText(frame, tag, (points[0][0] + 10, points[0][1] + 6),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.55,
                        (0, 255, 200) if track["label"] else (120, 120, 120),
                        2, cv2.LINE_AA)

    if not tracks:
        text = "no hand"
        colour = (120, 120, 120)
    elif len(tracks) == 1 and tracks[0]["label"]:
        text = "%s  %.2f" % (tracks[0]["label"], tracks[0]["confidence"])
        colour = (0, 255, 200)
    elif len(tracks) == 1:
        text = "unrecognised  %.2f / %.2f" % (tracks[0]["confidence"],
                                              threshold)
        colour = (120, 120, 120)
    else:
        # Every hand on one line, in detection order, so the chip still says
        # what the whole frame is doing.
        text = "   ".join(
            "%s %.2f" % (t["label"], t["confidence"]) if t["label"]
            else "unrecognised %.2f" % t["confidence"] for t in tracks)
        colour = ((0, 255, 200) if any(t["label"] for t in tracks)
                  else (120, 120, 120))

    (tw, th), _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_SIMPLEX, 0.8, 2)
    cv2.rectangle(frame, (10, 10), (22 + tw, 30 + th), (14, 17, 22), -1)
    cv2.putText(frame, text, (16, 24 + th), cv2.FONT_HERSHEY_SIMPLEX, 0.8,
                colour, 2, cv2.LINE_AA)
    return frame


class SharedState:
    """Latest annotated frame + gesture, shared with the HTTP threads."""

    def __init__(self):
        self.lock = threading.Condition()
        self.jpeg = None
        self.seq = 0
        self.snapshot_data = {}
        self.viewers = 0
        self.frames_in = 0
        self.frames_inferred = 0
        self._in_times = []
        self._infer_times = []

    def publish(self, jpeg, data):
        with self.lock:
            self.jpeg = jpeg
            self.seq += 1
            self.snapshot_data = data
            self.lock.notify_all()

    def note_frame_in(self):
        with self.lock:
            self.frames_in += 1
            self._in_times.append(time.monotonic())
            self._in_times = self._in_times[-30:]

    def note_inferred(self):
        """One cycle finished. Counted here rather than in publish().

        publish() only runs when the web view is on, so counting there made
        infer_fps read 0.0 under publish_web:=false -- on the dashboard that
        is indistinguishable from a node that has stopped analysing, which is
        the one thing the number exists to tell you.
        """
        with self.lock:
            self.frames_inferred += 1
            self._infer_times.append(time.monotonic())
            self._infer_times = self._infer_times[-30:]

    @staticmethod
    def _rate(times):
        if len(times) < 2:
            return 0.0
        span = times[-1] - times[0]
        return round((len(times) - 1) / span, 1) if span > 0 else 0.0

    def rates(self):
        """(frames arriving, frames analysed) per second."""
        with self.lock:
            return self._rate(self._in_times), self._rate(self._infer_times)

    def add_viewer(self, delta):
        with self.lock:
            self.viewers = max(0, self.viewers + delta)

    def latest_jpeg(self):
        with self.lock:
            return self.jpeg

    def wait_for_frame(self, last_seq, timeout=5.0):
        with self.lock:
            if self.seq == last_seq:
                self.lock.wait(timeout)
            return self.jpeg, self.seq

    def snapshot(self):
        with self.lock:
            out = dict(self.snapshot_data)
            out.update({
                "stream_fps": self._rate(self._in_times),
                "infer_fps": self._rate(self._infer_times),
                "frames_in": self.frames_in,
                "frames_inferred": self.frames_inferred,
                "viewers": self.viewers,
            })
            return out


class GestureNode(Node):

    def __init__(self):
        super().__init__("x2_gesture")

        # -- input ---------------------------------------------------------- #
        self.declare_parameter("image_topic", "")
        # >= 0 opens a local V4L2 camera instead of subscribing. The escape
        # hatch for testing on a laptop; on the robot the cameras live on other
        # SoCs and are only reachable over DDS.
        self.declare_parameter("camera_device", -1)
        self.declare_parameter("model_path",
                               "/home/agi/x2_yolo_plus_ws/models/gesture_model.json")
        self.declare_parameter("landmarker_path",
                               "/home/agi/x2_yolo_plus_ws/models/hand_landmarker.task")

        # -- detection ------------------------------------------------------ #
        # "cpu" and not "auto", on purpose. The Orin's GPU already belongs to
        # x2_yolo_stream, which gets 10x from it on a model far bigger than
        # this one; MediaPipe's GPU delegate is worth 2-3x on a landmarker
        # small enough that the frame upload is most of the cost. Two
        # processes contending for one GPU to speed up the cheaper of them is
        # a bad trade, so the split is deliberate: YOLO on the GPU, hands on
        # the CPU.
        #
        # "gpu" or "auto" switches it, and everything needed for that is in
        # place and safe -- see runtime.py and the README. Measure both before
        # deciding; the node reports inference_ms either way. Note that "gpu"
        # does NOT make the node fail when there is no GPU: runtime.py always
        # keeps the CPU behind it.
        self.declare_parameter("delegate", "cpu")
        # The GPU delegate aborts the process rather than raising when it
        # cannot run, so it is verified in a child process first. Costs a few
        # seconds at startup and is skipped entirely on the CPU path, where
        # there is nothing to fall back to. false only if you like crashes.
        self.declare_parameter("probe_delegate", True)
        self.declare_parameter("num_hands", 1)
        # MediaPipe's own gates, not the classifier's: how sure it must be that
        # a hand is a hand before landmarks come out at all.
        self.declare_parameter("min_detection_confidence", 0.5)
        self.declare_parameter("min_tracking_confidence", 0.5)
        # The classifier's gate: smoothed confidence needed to commit a label.
        # Below it the topic reports the scores but no gesture.
        self.declare_parameter("threshold", 0.75)
        # Frames averaged before committing. Raising it makes the label steadier
        # and slower to react; the /detections topic carries both the smoothed
        # and the instantaneous scores so this can be tuned from an echo.
        self.declare_parameter("smoothing", 5)
        self.declare_parameter("infer_fps", 10.0)
        # Landmarking cost scales with pixels and the hand is a small part of
        # the frame; 640 is plenty and keeps a cycle affordable.
        self.declare_parameter("max_width", 640)

        # -- output --------------------------------------------------------- #
        # Namespace for this node's topics, so a second instance watching
        # another camera does not publish over the first one's.
        self.declare_parameter("topic_prefix", "/gesture")
        self.declare_parameter("publish_detections", True)
        self.declare_parameter("publish_summary", True)
        # A plain sentence on <prefix>/text. `ros2 topic echo` on the JSON
        # topic is a wall of scores; this is the line you actually wanted.
        self.declare_parameter("publish_text", True)
        self.declare_parameter("pretty_summary", True)
        self.declare_parameter("pretty_detections", False)
        # Publish the summary only when the gesture actually changes, so a
        # behaviour node can sit on it without a 10 Hz firehose. The heartbeat
        # still goes out at summary_max_period.
        self.declare_parameter("summary_on_change_only", True)
        self.declare_parameter("summary_max_period", 5.0)
        self.declare_parameter("qos_fallback_seconds", 12.0)

        # -- overlay base --------------------------------------------------- #
        # Draw the hand overlay onto the frame x2_yolo_stream has already drawn
        # boxes on, so one stream carries both layers instead of the dashboard
        # showing two videos of the same camera. Empty disables it.
        #
        # Classification still runs on the RAW camera. Landmarking a frame with
        # detection boxes drawn across it would corrupt the landmarks, so this
        # image is a canvas and nothing else.
        self.declare_parameter("overlay_base_topic",
                               "/yolo/image_annotated/compressed")
        # Past this age the base frame is ignored and the raw camera is drawn
        # on instead. Without it, a dead x2_yolo_stream leaves one frozen frame
        # under a live skeleton, which looks like the camera has stopped.
        self.declare_parameter("overlay_base_max_age", 2.0)

        # -- web view ------------------------------------------------------- #
        self.declare_parameter("publish_web", True)
        self.declare_parameter("host", "0.0.0.0")
        # 8081 is x2_yolo_stream's. Two nodes on one port is a silent failure
        # where whichever started second serves nothing.
        self.declare_parameter("port", 8082)
        self.declare_parameter("jpeg_quality", 80)

        p = self.get_parameter
        self.camera_device = int(p("camera_device").value)
        self.num_hands = max(1, int(p("num_hands").value))
        self.threshold = float(p("threshold").value)
        self.smoothing = max(1, int(p("smoothing").value))
        self.infer_fps = max(0.5, float(p("infer_fps").value))
        self.max_width = int(p("max_width").value)
        self.publish_detections = bool(p("publish_detections").value)
        self.publish_summary = bool(p("publish_summary").value)
        self.publish_text = bool(p("publish_text").value)
        self.pretty_summary = bool(p("pretty_summary").value)
        self.pretty_detections = bool(p("pretty_detections").value)
        self.summary_on_change_only = bool(p("summary_on_change_only").value)
        self.summary_max_period = float(p("summary_max_period").value)
        self.qos_fallback_seconds = float(p("qos_fallback_seconds").value)
        self.publish_web = bool(p("publish_web").value)
        self.jpeg_quality = int(p("jpeg_quality").value)
        self.overlay_base_topic = str(p("overlay_base_topic").value).strip()
        self.overlay_base_max_age = float(p("overlay_base_max_age").value)

        # Latest annotated frame from x2_yolo_stream, still compressed. Decoded
        # in the worker, never in the DDS callback -- the callback's only job is
        # to be fast enough not to drop the executor behind.
        self._base_slot = None
        self._base_lock = threading.Lock()

        # -- model ---------------------------------------------------------- #
        model_path = str(p("model_path").value)
        self.get_logger().info("loading %s" % model_path)
        self.clf = GestureClassifier(model_path)
        self.get_logger().info(
            "%d classes: %s" % (len(self.clf.classes), ", ".join(self.clf.classes)))
        self.get_logger().info(
            "validation accuracy at export: %.3f" % self.clf.val_accuracy)
        # Before any publisher exists. A featurizer that disagrees with the
        # browser returns confident wrong answers rather than an error, and a
        # behaviour node downstream cannot tell the difference -- so this node
        # refuses to join the graph at all rather than lie to it.
        self.clf.verify()

        landmarker_path = str(p("landmarker_path").value)
        self.get_logger().info("loading %s" % landmarker_path)
        requested_delegate = str(p("delegate").value).strip().lower()
        # Report the runtime before loading anything: when the GPU is wanted
        # and missing, this line is what explains every number below it. On
        # the plain CPU default there is nothing to explain, so it stays short.
        self.get_logger().info(
            describe_environment(check_gl=requested_delegate != "cpu"))
        self.landmarker = make_landmarker(
            landmarker_path,
            delegate=requested_delegate,
            num_hands=self.num_hands,
            min_detection_confidence=float(
                p("min_detection_confidence").value),
            min_tracking_confidence=float(
                p("min_tracking_confidence").value),
            probe_first=bool(p("probe_delegate").value),
            logger=self.get_logger().info,
        )
        # What it is ACTUALLY on, not what was asked for. Kept on the node so
        # the topics and the web view report the same thing the log did.
        self.delegate = self.landmarker.delegate
        self.get_logger().info(
            "hand landmarker: %s, blank-frame pass %.0f ms"
            % (self.landmarker.label, self.landmarker.warmup_ms))
        # Only when the GPU was asked for and not given. The plain CPU default
        # is the intended configuration on this robot, not a degraded one, and
        # a warning on the happy path teaches people to ignore warnings.
        if requested_delegate != "cpu" and self.delegate == "cpu":
            self.get_logger().warning(
                "delegate:=%s was requested but landmarking fell back to the "
                "CPU -- the lines above say which part failed, and the README "
                "section 'If the GPU is refused' says what to do about each "
                "one" % requested_delegate)

        # -- state ---------------------------------------------------------- #
        # One smoothing window per hand, not one per frame: with num_hands > 1
        # a shared window would average a left fist and a right peace into a
        # distribution neither hand is making. Keyed by (handedness, nth of
        # that handedness) -- the landmarker does not track hands between
        # frames, so that is the closest thing to an identity it gives us.
        self.histories = {}
        self._current_key = None
        self._since = time.monotonic()
        self._changes = 0
        self._last_summary_key = None
        self._last_summary_time = 0.0
        self._frames = 0
        self.state = SharedState()
        self.httpd = None

        # -- topics --------------------------------------------------------- #
        prefix = str(p("topic_prefix").value).rstrip("/") or "/gesture"
        self.pub_dets = self.create_publisher(String, prefix + "/detections", 10)
        self.pub_summary = self.create_publisher(String, prefix + "/summary", 10)
        self.pub_text = self.create_publisher(String, prefix + "/text", 10)

        # latest-frame-wins slot between the DDS callback and the worker
        self._slot = None
        self._slot_lock = threading.Lock()
        self._wake = threading.Event()
        self._stop = threading.Event()

        self._sub = None
        self._cap = None
        self.topic = ""
        self._last_frame_time = time.monotonic()

        if self.camera_device >= 0:
            self.topic = "camera:%d" % self.camera_device
            self._cap = cv2.VideoCapture(self.camera_device)
            if not self._cap.isOpened():
                raise SystemExit("could not open camera %d" % self.camera_device)
            self.get_logger().warning(
                "reading local camera %d -- this is the dev path, not the robot "
                "path" % self.camera_device)
        else:
            self.topic = self._resolve_topic(str(p("image_topic").value))
            self._use_best_effort = True
            self._subscribe()
            self.create_timer(2.0, self._watchdog)

        # Independent of the camera subscription above, and of camera_device:
        # even reading a local webcam, the annotated frames still arrive over
        # DDS if x2_yolo_stream is watching the same scene.
        if self.overlay_base_topic:
            base_qos = QoSProfile(depth=1, history=HistoryPolicy.KEEP_LAST,
                                  reliability=ReliabilityPolicy.BEST_EFFORT,
                                  durability=DurabilityPolicy.VOLATILE)
            self.create_subscription(CompressedImage, self.overlay_base_topic,
                                     self._on_base_image, base_qos)
            self.get_logger().info(
                "overlay base: %s (falls back to the raw camera if it goes "
                "quiet for %.1fs)"
                % (self.overlay_base_topic, self.overlay_base_max_age))

        self.worker = threading.Thread(target=self._infer_loop, daemon=True)
        self.worker.start()

        if self.publish_web:
            host, port = str(p("host").value), int(p("port").value)
            try:
                self.httpd = serve(self.state, host, port)
            except OSError as exc:
                # Almost always "address already in use" -- a second instance,
                # or someone put this on 8081 next to x2_yolo_stream. Losing
                # the web view is not worth killing gesture publishing over.
                self.get_logger().error(
                    "web view disabled: cannot bind %s:%d (%s)"
                    % (host, port, exc))
            else:
                threading.Thread(target=self.httpd.serve_forever,
                                 daemon=True).start()
                for ip in ["localhost"] + local_ips():
                    self.get_logger().info("viewer: http://%s:%d/" % (ip, port))

        self.get_logger().info(
            "gesture up: %s -> %s/{detections,summary,text}, threshold %.2f, "
            "smoothing %d frames, %.0f fps cap, feature spec v%d"
            % (self.topic, prefix, self.threshold, self.smoothing,
               self.infer_fps, SPEC_VERSION))

    # -- subscription ------------------------------------------------------- #

    def _resolve_topic(self, requested):
        if requested:
            return requested
        # Discovery needs a moment before the graph is complete.
        deadline = time.monotonic() + 20.0
        while time.monotonic() < deadline:
            available = {name for name, _ in self.get_topic_names_and_types()}
            for candidate in TOPIC_PREFERENCE:
                if candidate in available:
                    return candidate
            time.sleep(0.5)
        fallback = TOPIC_PREFERENCE[0]
        self.get_logger().warning(
            "no camera topic discovered; will wait on %s" % fallback)
        return fallback

    def _subscribe(self):
        if self._sub is not None:
            self.destroy_subscription(self._sub)
        reliability = (ReliabilityPolicy.BEST_EFFORT if self._use_best_effort
                       else ReliabilityPolicy.RELIABLE)
        qos = QoSProfile(depth=1, history=HistoryPolicy.KEEP_LAST,
                         reliability=reliability,
                         durability=DurabilityPolicy.VOLATILE)
        self._sub = self.create_subscription(
            CompressedImage, self.topic, self._on_image, qos)
        self.get_logger().info(
            "subscribed to %s (%s)" % (self.topic, reliability.name))

    def _watchdog(self):
        """If nothing arrives, flip reliability and resubscribe."""
        idle = time.monotonic() - self._last_frame_time
        if idle < self.qos_fallback_seconds:
            return
        self._use_best_effort = not self._use_best_effort
        self.get_logger().warning(
            "no frames for %.0fs, retrying with %s"
            % (idle, "BEST_EFFORT" if self._use_best_effort else "RELIABLE"))
        self._last_frame_time = time.monotonic()
        self._subscribe()

    def _on_base_image(self, msg):
        """Annotated frame from x2_yolo_stream. Stored compressed, decoded later."""
        with self._base_lock:
            self._base_slot = (bytes(msg.data), time.monotonic())

    def _base_fresh(self):
        """Is there a recent annotated frame to draw on? Timestamp only.

        Cheap on purpose -- no decode -- because the detections topic reports
        it every cycle whether or not the web view is running. It is what lets
        a consumer say "boxes + skeleton" without guessing from x2_yolo_stream
        being alive, which is a different question: the node can be publishing
        detections happily with publish_annotated:=false.
        """
        if not self.overlay_base_topic:
            return False
        with self._base_lock:
            item = self._base_slot
        return (item is not None
                and time.monotonic() - item[1] <= self.overlay_base_max_age)

    def _overlay_base(self, width, height):
        """The freshest annotated frame, resized to (width, height), or None.

        Returned at the gesture frame's size so the caller can draw landmarks
        without rescaling them: the two nodes size their frames independently
        (each has its own max_width), and matching the canvas to the points is
        simpler than matching every point to the canvas.
        """
        with self._base_lock:
            item = self._base_slot
        if item is None:
            return None
        data, stamped = item
        if time.monotonic() - stamped > self.overlay_base_max_age:
            return None                # x2_yolo_stream has gone quiet
        try:
            frame = cv2.imdecode(np.frombuffer(data, dtype=np.uint8),
                                 cv2.IMREAD_COLOR)
        except Exception:                                   # noqa: BLE001
            return None
        if frame is None:
            return None
        if frame.shape[1] != width or frame.shape[0] != height:
            frame = cv2.resize(frame, (width, height),
                               interpolation=cv2.INTER_AREA)
        return frame

    def _on_image(self, msg):
        """Keep this cheap: store the bytes, let the worker do the work."""
        self._last_frame_time = time.monotonic()
        self.state.note_frame_in()
        with self._slot_lock:
            self._slot = (bytes(msg.data), msg.header.stamp.sec,
                          msg.header.stamp.nanosec, msg.header.frame_id)
        self._wake.set()

    # -- inference ---------------------------------------------------------- #

    def _next_frame(self, min_interval):
        """One decoded frame plus its stamp, or None to skip this cycle."""
        if self._cap is not None:
            ok, frame = self._cap.read()
            if not ok:
                return None
            self.state.note_frame_in()
            now = self.get_clock().now().to_msg()
            return frame, now.sec, now.nanosec, "camera"

        if not self._wake.wait(timeout=0.5):
            return None
        self._wake.clear()
        with self._slot_lock:
            item, self._slot = self._slot, None
        if item is None:
            return None

        data, sec, nanosec, frame_id = item
        try:
            frame = cv2.imdecode(np.frombuffer(data, dtype=np.uint8),
                                 cv2.IMREAD_COLOR)
        except Exception as exc:                            # noqa: BLE001
            self.get_logger().warning("decode failed: %s" % exc)
            return None
        if frame is None:
            return None
        return frame, sec, nanosec, frame_id

    def _infer_loop(self):
        min_interval = 1.0 / self.infer_fps
        next_allowed = 0.0
        # The frame timestamps MediaPipe's VIDEO mode insists on are the
        # Landmarker's business, not this loop's -- see runtime.py. The DDS
        # header stamp could never have been used for them anyway: frames from
        # another SoC arrive with equal or backwards stamps.

        while not self._stop.is_set():
            now = time.monotonic()
            if now < next_allowed:
                time.sleep(min(0.01, next_allowed - now))
                continue

            item = self._next_frame(min_interval)
            if item is None:
                continue
            next_allowed = time.monotonic() + min_interval

            frame, sec, nanosec, frame_id = item
            if self.max_width and frame.shape[1] > self.max_width:
                scale = self.max_width / frame.shape[1]
                frame = cv2.resize(
                    frame, (self.max_width, int(frame.shape[0] * scale)),
                    interpolation=cv2.INTER_AREA)

            began = time.monotonic()
            try:
                # BGR straight in. The colour conversion belongs to the
                # Landmarker because it depends on the delegate -- the GPU
                # path takes 4 channels and aborts the process on 3.
                result = self.landmarker.detect(frame)
            except Exception as exc:                        # noqa: BLE001
                self.get_logger().error("landmarking failed: %s" % exc,
                                        throttle_duration_sec=5.0)
                continue

            # Every hand the landmarker returned, not just the first: with
            # num_hands > 1 the ones past index 0 were detected and then
            # thrown away, which reads as the model missing a hand it in fact
            # found.
            worlds = result.hand_world_landmarks or []
            hands = len(worlds)
            height, width = frame.shape[0], frame.shape[1]
            tracks = []
            seen = {}
            for i, world in enumerate(worlds):
                try:
                    lm = [[p.x, p.y, p.z] for p in world]
                    handedness = result.handedness[i][0].category_name
                    instant = self.clf.predict(featurize(lm, handedness))
                    # Screen landmarks are normalised to the frame and are only
                    # used for drawing -- the classifier reads world landmarks.
                    points = [(int(q.x * width), int(q.y * height))
                              for q in result.hand_landmarks[i]]
                except Exception as exc:                    # noqa: BLE001
                    # One bad hand loses that hand, not the frame: the others
                    # are still worth publishing.
                    self.get_logger().error("classification failed: %s" % exc,
                                            throttle_duration_sec=5.0)
                    continue

                seen[handedness] = seen.get(handedness, 0) + 1
                key = (handedness, seen[handedness])
                history = self.histories.get(key)
                if history is None:
                    history = self.histories[key] = deque(
                        maxlen=self.smoothing)
                history.append(instant)
                label, confidence, smoothed = self._smooth(history)
                tracks.append({
                    "handedness": handedness,
                    "instant": instant,
                    "points": points,
                    "label": label,
                    "confidence": confidence,
                    "smoothed": smoothed,
                })

            elapsed_ms = (time.monotonic() - began) * 1000.0
            self._frames += 1
            # A cycle is analysed here, whether or not anyone is watching.
            self.state.note_inferred()

            # Carrying stale probabilities across an empty gap makes a gesture
            # appear to linger after the hand is gone -- and a window kept for
            # a hand that left the frame is that same bug one hand deeper.
            for key in list(self.histories):
                if seen.get(key[0], 0) < key[1]:
                    del self.histories[key]

            # One hand still leads the summary topics and the top-level fields:
            # subscribers act on "what is the hand doing", and a list is the
            # wrong shape for that. The strongest committed hand wins, so a
            # second hand resting in frame cannot outvote the gesturing one.
            primary = None
            if tracks:
                committed = [t for t in tracks if t["label"]]
                primary = max(committed or tracks, key=lambda t: t["confidence"])

            if primary is None:
                instant, handedness = None, None
                label, confidence, smoothed = self._smooth(None)
            else:
                instant = primary["instant"]
                handedness = primary["handedness"]
                label = primary["label"]
                confidence = primary["confidence"]
                smoothed = primary["smoothed"]

            try:
                self._publish(instant, smoothed, label, confidence, handedness,
                              hands, sec, nanosec, frame_id, elapsed_ms, tracks)
            except Exception as exc:                        # noqa: BLE001
                self.get_logger().error("publish failed: %s" % exc)

            if self.publish_web:
                try:
                    self._serve_frame(frame, tracks, label, confidence,
                                      handedness, hands, smoothed, elapsed_ms)
                except Exception as exc:                    # noqa: BLE001
                    # A broken overlay must not stop the topics. They are what
                    # the robot acts on; the web view is for a human.
                    self.get_logger().error("web frame failed: %s" % exc,
                                            throttle_duration_sec=5.0)

    def _serve_frame(self, frame, tracks, label, confidence, handedness, hands,
                     smoothed, elapsed_ms):
        # Prefer x2_yolo_stream's annotated frame as the canvas, so this one
        # stream carries boxes and skeleton together. The landmarks were
        # computed from the raw camera either way -- only what they are drawn
        # on changes.
        canvas = self._overlay_base(frame.shape[1], frame.shape[0])
        base_live = canvas is not None
        if not base_live:
            canvas = frame

        annotated = draw_overlay(canvas, tracks, self.threshold)
        ok, buf = cv2.imencode(".jpg", annotated,
                               [int(cv2.IMWRITE_JPEG_QUALITY),
                                self.jpeg_quality])
        if not ok:
            return
        self.state.publish(buf.tobytes(), {
            "topic": self.topic,
            # False means this frame is the raw camera: either the overlay base
            # is switched off, or x2_yolo_stream has stopped publishing.
            "overlay_base": base_live,
            "width": annotated.shape[1],
            "height": annotated.shape[0],
            "spec_version": SPEC_VERSION,
            "classes": list(self.clf.classes),
            "gesture": label,
            "confidence": round(confidence, 4) if label else 0.0,
            "handedness": handedness,
            "hands": hands,
            "threshold": self.threshold,
            "smoothing": self.smoothing,
            "held_seconds": round(time.monotonic() - self._since, 1),
            "changes": self._changes,
            "scores": {c: round(float(s), 4)
                       for c, s in zip(self.clf.classes, smoothed)},
            "per_hand": self._per_hand(tracks),
            "inference_ms": round(elapsed_ms, 1),
            "delegate": self.delegate,
        })

    # -- publishing --------------------------------------------------------- #

    @staticmethod
    def _dump(payload, pretty):
        # ensure_ascii=False so non-Latin class names stay legible rather than
        # arriving as escapes in a terminal.
        if pretty:
            return json.dumps(payload, indent=2, ensure_ascii=False)
        return json.dumps(payload, ensure_ascii=False)

    @staticmethod
    def _describe(label, handedness, confidence, hands, held=None):
        if not hands:
            return "no hand"
        hand = "%s hand" % handedness.lower() if handedness else "hand"
        if label is None:
            return "unrecognised, %s, best %.2f" % (hand, confidence)
        if held is None:
            return "%s, %s, %.2f" % (label, hand, confidence)
        return "%s, %s, held %.1fs" % (label, hand, held)

    @classmethod
    def _describe_hands(cls, tracks, hands, held=None):
        """One line for the whole frame -- every hand it found.

        A single hand reads exactly as it did before this took a list; the
        joined form only appears when there is a second hand to join.
        """
        if not tracks:
            # A detected hand the classifier could not use is not "no hand":
            # the error log says why, and this must not claim the frame was
            # empty when it was not.
            return "no hand" if not hands else "hand, unclassified"
        if len(tracks) == 1:
            t = tracks[0]
            return cls._describe(t["label"], t["handedness"], t["confidence"],
                                 1, held)
        text = " + ".join(cls._describe(t["label"], t["handedness"],
                                        t["confidence"], 1) for t in tracks)
        return text if held is None else "%s, held %.1fs" % (text, held)

    def _per_hand(self, tracks):
        """Per-hand block for the JSON topics, in detection order."""
        classes = self.clf.classes
        return [{
            "handedness": t["handedness"],
            "gesture": t["label"],
            "confidence": round(t["confidence"], 4) if t["label"] else 0.0,
            "scores": {c: round(float(s), 4)
                       for c, s in zip(classes, t["smoothed"])},
        } for t in tracks]

    def _smooth(self, history):
        """Committed label, its confidence, and the averaged distribution.

        Over one hand's window -- the caller owns the windows, because which
        hand a frame's landmarks belong to is decided in _infer_loop.
        """
        if not history:
            return None, 0.0, np.zeros(len(self.clf.classes), dtype=np.float32)
        smoothed = np.mean(history, axis=0)
        best = int(np.argmax(smoothed))
        best_score = float(smoothed[best])
        label = self.clf.classes[best] if best_score >= self.threshold else None
        return label, best_score, smoothed

    def _publish(self, instant, smoothed, label, best_score, handedness, hands,
                 sec, nanosec, frame_id, elapsed_ms, tracks):
        classes = self.clf.classes
        description = self._describe_hands(tracks, hands)
        stream_fps, infer_fps = self.state.rates()

        if self.publish_detections:
            msg = String()
            msg.data = self._dump({
                # First key, so the head of an echo is the answer.
                "description": description,
                "stamp": {"sec": int(sec), "nanosec": int(nanosec)},
                "frame_id": frame_id,
                "source_topic": self.topic,
                # True when the annotated stream on this node's web view is
                # x2_yolo_stream's frame with the hand drawn over it, so a
                # viewer can label the layers honestly rather than inferring
                # them from whether YOLO happens to be alive.
                "overlay_base": self._base_fresh(),
                "spec_version": SPEC_VERSION,
                "classes": list(classes),
                "gesture": label,
                "confidence": round(best_score, 4) if label else 0.0,
                "handedness": handedness,
                "hands": hands,
                "threshold": self.threshold,
                "smoothing": self.smoothing,
                "scores": {c: round(float(s), 4)
                           for c, s in zip(classes, smoothed)},
                "instant": ({c: round(float(s), 4)
                             for c, s in zip(classes, instant)}
                            if instant is not None else None),
                # Every hand, in detection order. The keys above are the one
                # answer a subscriber acts on -- the leading hand -- and stay
                # where they were; this is for the ones that want both hands.
                "per_hand": self._per_hand(tracks),
                "inference_ms": round(elapsed_ms, 1),
                # "gpu" or "cpu" -- what the landmarker is really on. Next to
                # inference_ms because the two only make sense together: 40 ms
                # is good on the CPU and bad on the GPU.
                "delegate": self.delegate,
                # Rate as well as cost, and both rates: frames analysed against
                # frames arriving is what separates "the model is slow" from
                # "infer_fps is capping it" from "the camera stopped".
                "stream_fps": stream_fps,
                "infer_fps": infer_fps,
            }, self.pretty_detections)
            self.pub_dets.publish(msg)

        if self.publish_summary or self.publish_text:
            self._publish_summary(label, handedness, best_score, hands, sec,
                                  nanosec, tracks)

    def _publish_summary(self, label, handedness, confidence, hands, sec,
                         nanosec, tracks):
        """Compact "what is the hand doing" topic, rate limited to changes.

        A confidence wobble is not a change: the key is the committed label and
        which hand it is on -- every hand, so a second hand starting a gesture
        counts -- and a subscriber is not woken ten times a second by a frame
        that says the same thing as the last one.
        """
        key = tuple((t["label"], t["handedness"]) for t in tracks)
        now = time.monotonic()
        if key != self._current_key:
            self._current_key = key
            self._since = now
            self._changes += 1

        held = now - self._since

        if (self.summary_on_change_only and key == self._last_summary_key and
                now - self._last_summary_time < self.summary_max_period):
            return
        self._last_summary_key = key
        self._last_summary_time = now

        committed = any(t["label"] for t in tracks)
        description = self._describe_hands(tracks, hands,
                                           held=held if committed else None)

        if self.publish_text:
            # Plain text, not JSON: an echo of <prefix>/text should read like a
            # sentence, and it does not need quoting to.
            text = String()
            text.data = description
            self.pub_text.publish(text)

        if not self.publish_summary:
            return

        msg = String()
        msg.data = self._dump({
            "description": description,
            "stamp": {"sec": int(sec), "nanosec": int(nanosec)},
            "gesture": label,
            "confidence": round(confidence, 4) if label else 0.0,
            "handedness": handedness,
            "per_hand": self._per_hand(tracks),
            "held_seconds": round(held, 2),
            "changes": self._changes,
        }, self.pretty_summary)
        self.pub_summary.publish(msg)

    def destroy_node(self):
        self._stop.set()
        self._wake.set()
        if self.httpd is not None:
            try:
                self.httpd.shutdown()
            except Exception:                               # noqa: BLE001
                pass
        if self._cap is not None:
            try:
                self._cap.release()
            except Exception:                               # noqa: BLE001
                pass
        # Only after the worker has stopped: closing the graph out from under
        # an in-flight detect() tears down the GL context mid-frame, which
        # ends the process with a native stack trace instead of a clean exit.
        # If the worker will not come back, leave it to the OS -- a hung
        # shutdown is worse than a leaked context on a process that is going
        # away anyway.
        self.worker.join(timeout=2.0)
        if not self.worker.is_alive():
            self.landmarker.close()
        return super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = GestureNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == "__main__":
    main()
